# Kavach: mine vehicle safety monitor

Kavach is a prototype collision-awareness system for mining vehicles. An ESP32 reads
obstacle distance, object temperature and GPS position, listens for signals from nearby
trucks, and warns the driver with a buzzer and vibration motor. A browser dashboard shows
everything live. A Raspberry Pi Pico stands in for a second truck so the vehicle-to-vehicle
(V2V) behaviour can be demonstrated on a desk.

> Status: working prototype for demonstration. Not a certified safety device. Do not rely
> on it to prevent real collisions.

## Features

- **Obstacle detection** with an HC-SR04 ultrasonic sensor (safe, warning and danger zones).
- **Thermal sensing** with an MLX90614 infrared sensor (flags warm objects above 30 C).
- **GPS** position, speed and satellite count.
- **Driver alerts**: buzzer and vibration motor, with patterns that change by zone.
- **V2V demo**: a Raspberry Pi Pico broadcasts a fake truck's position and speed; the ESP32
  works out distance and bearing and raises alerts.
- **Live dashboard** (single HTML file): gauges, status banner, GPS panel, and a radar view
  of nearby trucks, plus a built-in truck simulation that needs no hardware.

## Repository layout

```
kavach/
  firmware/
    esp32/kavach_esp32/kavach_esp32.ino   ESP32 sketch (Arduino)
    pico/main.py                          Pico script (MicroPython), the fake truck
  dashboard/index.html                    Browser dashboard (open in Chrome or Edge)
  docs/                                   Photos, wiring diagrams, screenshots
  README.md
  LICENSE
```

## Hardware

| Part | Purpose |
|---|---|
| ESP32 dev board | Main controller |
| MLX90614 | Non-contact temperature sensor (I2C, address 0x5A) |
| HC-SR04 | Ultrasonic distance sensor |
| GPS module (UART, 9600 baud) | Position and speed |
| Buzzer (active) | Audible alert |
| Vibration motor | Haptic alert |
| 2 x 2N2222 transistors, 2 x 1 kOhm resistors | Drive the buzzer and motor |
| 1N4007 diode | Flyback diode across the motor (and across a magnetic buzzer) |
| Raspberry Pi Pico or Pico W | Fake second truck for the V2V demo |

### ESP32 pin map

| Function | ESP32 pin |
|---|---|
| MLX90614 SDA / SCL | GPIO21 / GPIO22 |
| HC-SR04 TRIG / ECHO | GPIO5 / GPIO18 |
| GPS RX2 / TX2 | GPIO16 / GPIO17 |
| Buzzer (via 2N2222) | GPIO25 |
| Vibration motor (via 2N2222) | GPIO32 |
| V2V link RX / TX (from Pico) | GPIO26 / GPIO27 |

### Transistor wiring (buzzer and motor)

Each output uses its own 2N2222 as a low-side switch, because ESP32 pins cannot supply
enough current directly.

```
ESP32 GPIO --[ 1 kOhm ]-- Base (2N2222)
           Collector ---- load (buzzer / motor) ---- 5V (VIN)
           Emitter   ---- GND
```

- Flyback diode across the motor (required): stripe (cathode) toward the + supply.
- Put a diode across the buzzer too if it is a magnetic type; skip it for a piezo buzzer.
- 2N2222 (TO-92, flat side facing you): Emitter, Base, Collector from left to right.
  Check your part's pinout, as some clones differ.
- The HC-SR04 ECHO pin outputs 5 V when the sensor is powered from 5 V. The ESP32 inputs
  are 3.3 V, so use a voltage divider on ECHO (for example 1 kOhm and 2 kOhm) or a 3.3 V
  compatible sensor.

### Pico to ESP32 link

| Raspberry Pi Pico | ESP32 |
|---|---|
| GP0 (pin 1, TX) | GPIO26 (RX) |
| GND (pin 3) | GND |

Power each board from its own USB cable. Both use 3.3 V signals. The wire stands in for a
radio link (ESP-NOW does not work between an ESP32 and a Pico). The packet format stays the
same if you later swap in a radio module.

## Setup

### 1. ESP32 firmware

1. Install the Arduino IDE and add ESP32 board support (Boards Manager, "esp32" by Espressif).
2. Install the **TinyGPSPlus** library (Library Manager).
3. Open `firmware/esp32/kavach_esp32/kavach_esp32.ino`, select your ESP32 board and port,
   and upload.
4. Open the Serial Monitor at **115200 baud** to check the output.

### 2. Pico (fake truck)

1. Install [MicroPython](https://micropython.org/download/rp2-pico/) on the Pico and open
   [Thonny](https://thonny.org/).
2. Open `firmware/pico/main.py`, run it, and optionally save it to the Pico as `main.py`
   so it starts on power-up.
3. The onboard LED blinks with every packet.

The fake truck starts 250 m east of a demo point and drives west at 40 km/h, passing 15 m
from the ESP32 (inside the danger zone), then loops after about 45 seconds.

### 3. Dashboard

1. Open `dashboard/index.html` in **Chrome or Edge** on desktop (Web Serial is not
   available in Firefox or Safari).
2. Close the Arduino Serial Monitor, since only one program can use the port.
3. Click **Connect ESP32** and choose the ESP32's port.
4. Click **Simulate nearby trucks** for the built-in demo, or watch the Pico's truck appear
   as a "Live" truck when the link is wired.

The dashboard can also be hosted on GitHub Pages (Settings, then Pages, then deploy from
the `main` branch and `/dashboard` or `/root` folder). Web Serial works over HTTPS.

## Behaviour

| Source | Warning | Danger |
|---|---|---|
| Ultrasonic distance | under 100 cm | under 30 cm |
| Nearby truck distance | under 100 m | under 40 m |

| Zone | Buzzer | Motor |
|---|---|---|
| Safe | off | off |
| Warning | one short beep per second | off |
| Danger | fast beeping (100 ms on, 100 ms off) | on continuously |

The overall zone is the worse of the ultrasonic zone and the nearest truck's zone. A truck
that stops sending for 3 seconds is dropped.

## Data formats

**Serial output** (115200 baud, once per second):

```
Thermal: 31.2 C [WARM OBJECT]  |  Distance: 45.3 cm [WARNING]  |  GPS: no fix (sats: 3)
V2V: id=TRK-201 dist=85.3 brg=90 spd=40.0 hdg=270 zone=warning
```

**V2V packet** (Pico to ESP32, 9600 baud, newline terminated):

```
V2V,<id>,<latitude>,<longitude>,<speed km/h>,<heading degrees>
V2V,TRK-201,20.000135,78.002300,40.0,270
```

The ESP32 uses a fixed demo position as its own location (`USE_GPS_POSITION false`), so the
demo works indoors. `DEMO_LAT` / `DEMO_LNG` in the sketch must match `ORIGIN_LAT` /
`ORIGIN_LNG` in the Pico script. Set `USE_GPS_POSITION true` to use the real GPS instead.

## Known limitations

- The V2V link is a wire and the truck is simulated; no real radio is used yet.
- GPS does not work underground. A production system for underground mines would need
  beacons or radio signal strength for positioning at junctions.
- Distance is sampled about once a second, so an alert can lag a fast-moving obstacle.
- The dashboard needs a USB connection to a laptop running Chrome or Edge.

## Roadmap

- Time-to-collision alerts from speed, bearing and heading
- Methane and carbon monoxide sensing (MQ-4 and MQ-7)
- Worker tag (the Pico as a person on foot)
- SOS button and crash or rollover detection (MPU6050)
- Cabin OLED display
- Event log with export, spoken warnings, and a live map
- Wireless dashboard over WiFi

## License

MIT. See [LICENSE](LICENSE).
