// Kavach - ESP32 firmware
// Sensors: MLX90614 (thermal), HC-SR04 (ultrasonic), GPS
// Alerts : buzzer + vibration motor (via 2N2222 transistors)
// V2V    : receives truck packets from the Pico on UART1 (RX=26, TX=27)
#include <Wire.h>
#include <TinyGPS++.h>

// ---------- MLX90614 (thermal) ----------
#define MLX_ADDR 0x5A

// ---------- HC-SR04 (ultrasonic) ----------
#define TRIG_PIN 5
#define ECHO_PIN 18
#define DANGER_CM  30
#define WARNING_CM 100

// ---------- Driver alerts (via 2N2222 transistors) ----------
#define BUZZER_PIN 25
#define MOTOR_PIN  32

// ---------- V2V link from the Pico ----------
#define V2V_RX_PIN 26
#define V2V_TX_PIN 27
#define V2V_DANGER_M  40
#define V2V_WARNING_M 100
#define V2V_TIMEOUT_MS 3000
#define MAX_TRUCKS 4
// Own position when there is no GPS fix (indoor demo). Must match the Pico.
#define DEMO_LAT 20.000000
#define DEMO_LNG 78.000000
#define USE_GPS_POSITION false

enum Zone { ZONE_SAFE, ZONE_WARNING, ZONE_DANGER };
Zone sensorZone = ZONE_SAFE, v2vZone = ZONE_SAFE, currentZone = ZONE_SAFE;

struct Truck {
  char id[16];
  double lat, lng;
  float speed, heading;
  unsigned long lastMs;
  bool used;
};
Truck trucks[MAX_TRUCKS];

// ---------- GPS ----------
TinyGPSPlus gps;
HardwareSerial gpsSerial(2);   // UART2: RX2=16, TX2=17
HardwareSerial v2vSerial(1);   // UART1: RX=26, TX=27

unsigned long lastPrint = 0;
char v2vBuf[96];
int v2vLen = 0;

// ---- V2V receive ----
void handleV2VLine(char* line) {
  char id[16];
  double lat, lng;
  float spd, hdg;
  if (sscanf(line, "V2V,%15[^,],%lf,%lf,%f,%f", id, &lat, &lng, &spd, &hdg) != 5) return;

  int slot = -1;
  for (int i = 0; i < MAX_TRUCKS; i++)
    if (trucks[i].used && strcmp(trucks[i].id, id) == 0) { slot = i; break; }
  if (slot < 0)
    for (int i = 0; i < MAX_TRUCKS; i++)
      if (!trucks[i].used) { slot = i; break; }
  if (slot < 0) return;

  strcpy(trucks[slot].id, id);
  trucks[slot].lat = lat;
  trucks[slot].lng = lng;
  trucks[slot].speed = spd;
  trucks[slot].heading = hdg;
  trucks[slot].lastMs = millis();
  trucks[slot].used = true;
}

void readV2V() {
  while (v2vSerial.available()) {
    char c = v2vSerial.read();
    if (c == '\n') {
      v2vBuf[v2vLen] = 0;
      if (v2vLen > 0) handleV2VLine(v2vBuf);
      v2vLen = 0;
    } else if (c != '\r' && v2vLen < (int)sizeof(v2vBuf) - 1) {
      v2vBuf[v2vLen++] = c;
    }
  }
}

void ownPosition(double &lat, double &lng) {
  if (USE_GPS_POSITION && gps.location.isValid()) {
    lat = gps.location.lat();
    lng = gps.location.lng();
  } else {
    lat = DEMO_LAT;
    lng = DEMO_LNG;
  }
}

// Works out the worst zone across all trucks. Optionally prints each truck.
void updateV2VZone(bool printThem) {
  double myLat, myLng;
  ownPosition(myLat, myLng);
  Zone worst = ZONE_SAFE;

  for (int i = 0; i < MAX_TRUCKS; i++) {
    if (!trucks[i].used) continue;
    if (millis() - trucks[i].lastMs > V2V_TIMEOUT_MS) { trucks[i].used = false; continue; }

    double d = TinyGPSPlus::distanceBetween(myLat, myLng, trucks[i].lat, trucks[i].lng);
    double brg = TinyGPSPlus::courseTo(myLat, myLng, trucks[i].lat, trucks[i].lng);
    Zone z = d < V2V_DANGER_M ? ZONE_DANGER : d < V2V_WARNING_M ? ZONE_WARNING : ZONE_SAFE;
    if (z > worst) worst = z;

    if (printThem) {
      Serial.printf("V2V: id=%s dist=%.1f brg=%.0f spd=%.1f hdg=%.0f zone=%s\n",
                    trucks[i].id, d, brg, trucks[i].speed, trucks[i].heading,
                    z == ZONE_DANGER ? "danger" : z == ZONE_WARNING ? "warning" : "safe");
    }
  }
  v2vZone = worst;
}

// ---- Alert pattern (non-blocking) ----
// DANGER : fast beeps (100 ms on / 100 ms off), motor ON steadily
// WARNING: slow beeps (100 ms on / 900 ms off), motor OFF
// SAFE   : everything OFF
void updateAlerts() {
  unsigned long now = millis();
  bool buzzerOn = false;
  bool motorOn = false;

  if (currentZone == ZONE_DANGER) {
    buzzerOn = (now % 200) < 100;
    motorOn = true;
  } else if (currentZone == ZONE_WARNING) {
    buzzerOn = (now % 1000) < 100;
  }

  digitalWrite(BUZZER_PIN, buzzerOn ? HIGH : LOW);
  digitalWrite(MOTOR_PIN, motorOn ? HIGH : LOW);
}

// ---- MLX90614 read ----
float readMLX(byte reg) {
  Wire.beginTransmission(MLX_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return -999;
  if (Wire.requestFrom(MLX_ADDR, 3) != 3) return -999;
  byte low = Wire.read();
  byte high = Wire.read();
  Wire.read();                        // PEC byte, ignored
  return ((high << 8) | low) * 0.02 - 273.15;
}

// ---- HC-SR04 read (averaged) ----
float readOnceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long t = pulseIn(ECHO_PIN, HIGH, 30000);
  if (t == 0) return -1;
  return t * 0.0343 / 2.0;
}

float readDistanceCm() {
  float sum = 0;
  int count = 0;
  for (int i = 0; i < 5; i++) {
    float d = readOnceCm();
    if (d > 0) { sum += d; count++; }
    delay(15);
  }
  return count == 0 ? -1 : sum / count;
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  Wire.begin(21, 22);   // SDA, SCL

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(MOTOR_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(MOTOR_PIN, LOW);

  // Quick self-test: buzzer, then motor
  digitalWrite(BUZZER_PIN, HIGH); delay(200); digitalWrite(BUZZER_PIN, LOW);
  delay(200);
  digitalWrite(MOTOR_PIN, HIGH);  delay(300); digitalWrite(MOTOR_PIN, LOW);

  gpsSerial.begin(9600, SERIAL_8N1, 16, 17);                       // GPS
  v2vSerial.begin(9600, SERIAL_8N1, V2V_RX_PIN, V2V_TX_PIN);       // Pico link

  Serial.println("Kavach sensor test started");
  Serial.println("Waiting for GPS fix (needs clear sky view)...");
}

void loop() {
  while (gpsSerial.available() > 0) {
    gps.encode(gpsSerial.read());
  }

  readV2V();
  updateV2VZone(false);
  currentZone = (sensorZone > v2vZone) ? sensorZone : v2vZone;
  updateAlerts();

  if (millis() - lastPrint >= 1000) {
    lastPrint = millis();

    // ---- Thermal ----
    float object = readMLX(0x07);
    Serial.print("Thermal: ");
    if (object == -999) Serial.print("ERROR");
    else {
      Serial.print(object, 1);
      Serial.print(" C");
      if (object > 30) Serial.print(" [WARM OBJECT]");
    }

    // ---- Ultrasonic ----
    float dist = readDistanceCm();
    Serial.print("  |  Distance: ");
    if (dist < 0) {
      Serial.print("no echo");
      sensorZone = ZONE_SAFE;
    } else {
      Serial.print(dist, 1);
      Serial.print(" cm ");
      if (dist < DANGER_CM) {
        Serial.print("[DANGER]");
        sensorZone = ZONE_DANGER;
      } else if (dist < WARNING_CM) {
        Serial.print("[WARNING]");
        sensorZone = ZONE_WARNING;
      } else {
        Serial.print("[SAFE]");
        sensorZone = ZONE_SAFE;
      }
    }

    // ---- GPS ----
    Serial.print("  |  GPS: ");
    if (gps.location.isValid()) {
      Serial.print(gps.location.lat(), 6);
      Serial.print(", ");
      Serial.print(gps.location.lng(), 6);
      Serial.print("  Speed: ");
      Serial.print(gps.speed.kmph(), 1);
      Serial.print(" km/h");
    } else {
      Serial.print("no fix (sats: ");
      Serial.print(gps.satellites.value());
      Serial.print(")");
    }
    Serial.println();

    // ---- Nearby trucks (one line each) ----
    updateV2VZone(true);
  }
}
