# Kavach - Raspberry Pi Pico (MicroPython)
# Mimics a second truck: drives a fake route past the ESP32 and broadcasts
# V2V packets over UART. Works on Pico and Pico W.
#
# Wiring: Pico GP0 (TX) -> ESP32 GPIO26 (RX), Pico GND -> ESP32 GND
from machine import UART, Pin
import time, math

TRUCK_ID   = "TRK-201"
SPEED_KMH  = 40
START_X_M  = 250      # start 250 m east of the demo point
END_X_M    = -250     # drive west past it
OFFSET_Y_M = 15       # passes 15 m north of the demo point
SEND_EVERY = 0.5      # seconds between packets

ORIGIN_LAT = 20.000000   # must match DEMO_LAT / DEMO_LNG in the ESP32 sketch
ORIGIN_LNG = 78.000000

uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))
led = Pin("LED", Pin.OUT)

x = START_X_M
step = SPEED_KMH / 3.6 * SEND_EVERY   # metres moved per packet

while True:
    lat = ORIGIN_LAT + OFFSET_Y_M / 111320
    lng = ORIGIN_LNG + x / (111320 * math.cos(math.radians(ORIGIN_LAT)))
    msg = "V2V,%s,%.6f,%.6f,%.1f,%d\n" % (TRUCK_ID, lat, lng, SPEED_KMH, 270)
    uart.write(msg)
    print(msg.strip())
    led.toggle()
    x -= step
    if x < END_X_M:
        x = START_X_M
    time.sleep(SEND_EVERY)
